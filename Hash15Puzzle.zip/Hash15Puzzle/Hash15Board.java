import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;

/**
 * 
 */

/**
 * Hash15Board.java -- Hashable boards to store positions in solution of 15 puzzle, and create lists of available moves.
 * @author Jacob Wildenhaus
 * 9/29/2017
 *
 */
public class Hash15Board {
	
	public static final String solvedBd = "123456789ABCDEF0";//The solved version of the puzzle in string format
	public static final int [][]transitions = {{1, 4}, {0, 2, 5}, {1, 6, 3}, {2, 7}, {0, 5, 8}, {1, 4, 6, 9}, 
											{2, 5, 7, 10}, {3, 6, 11}, {4, 9, 12}, {5, 8, 10, 13}, {6, 9, 11,14}, 
											{7, 10, 15}, {8, 13}, {9, 12, 14}, {10, 13, 15}, {11, 14}};//All of the possible moves from a given space on the board
	public static Queue<Integer> moveOptions = new LinkedList<Integer>();//queue used for storing the legal move values
	
	public int hashCode() {
		return this.hashCode();
	}
	
	//method to print the board from string format
	public static void printBoard(String bd) {        
		for (int r = 0; r < 4; r++) {            
			for (int c = 0; c < 4; c++) {                
				System.out.print(bd.charAt(r*4 + c) + " ");            
				}           
			System.out.println();        
			}        
		System.out.println();    
		}    
	
	
	//method to swap the location of the empty space(0) to another space
	public static String move(String bd, int from, int empty) {        
		String newBd;        
		char fromChar = bd.charAt(from);        
		newBd = bd.replace('0', 'X').replace(fromChar, '0').replace('X', fromChar);        
		return newBd;   
	}
	
	//method to scramble the solved version of the 15 puzzle to a certain depth
	  public static String scrambleBoard(int depth) {        
		  int emptyCell = 15;     
		  Random myRand = new Random();
		  String bd = solvedBd;        
		  for (int i = 0; i < depth; i++) {            
			  int []legalMoves = transitions[emptyCell];            
			int cell = legalMoves[myRand.nextInt(legalMoves.length)];            
			  bd = move(bd, cell, emptyCell);            
			  emptyCell = cell;        
			  }        
		  return bd;    
	  }

	  
	  // method to solve the 15 puzzle once it has been scrambled
	  public static void brutalSolver(String board, int depth) {  
		  boolean check = false;
		  String oneMove = board;
		  Hashtable<String, Integer> knownBoards = new Hashtable<String, Integer>();     
		 
		  while(check == false) {

			 //checks if new board has already been seen, and if new board is solved
			 if(!knownBoards.contains(oneMove.hashCode()) && !oneMove.equals(solvedBd)) {
				knownBoards.put(oneMove, oneMove.hashCode());									//adds the board to the list of boards
				addToQueue(oneMove);															//adds the new moves to the queue
				System.out.println("Switching 0 with position " + moveOptions.peek());			//prints the spaced being swapped with the empty space
				oneMove = move(board, moveOptions.poll() , 15 );								//changes the board and removes the space from the queue. 
				printBoard(oneMove);															//Here is the problem. The board being compared is not the board from the previous move, but rather the previously checked board from any move
			 }
			 else if(oneMove.equals(solvedBd)) {
				 check = true;
			 }
			 else {
				 //if the board has already been seen, it is skipped
				 oneMove = move(board, moveOptions.poll() , 15 );
			 }
			 if(oneMove.equals(solvedBd))
				 check = true;
			  
		 }
		 
		  int emptyCell = oneMove.indexOf('0');        
		  boolean solved = bruteForce(oneMove, emptyCell, depth);                
		  if (solved)            
			  System.out.println("Ta da!");        
		  else            
			  System.out.println("No solution found to search depth " + depth);        
		  System.out.println("" + knownBoards.size() + " boards searched.");    
	  }
	  
	  //checks to see if the board is solved
	  public static boolean bruteForce(String bd, int emptyCell, int depth) { 
		  Boolean result = false;
		  if (bd.equalsIgnoreCase(solvedBd))
		  result = true;
		  return result;
	  }
	  
	  public static int[] legalMoves(int zeroPos) {
		return transitions[zeroPos];  
	  }
	  
	  //gets the legal moves for a certain board based off the location of the 0
	  public static int[] getLegalMoves(String bd) {
		int zeroPos = bd.indexOf("0");
		return legalMoves(zeroPos);
		
	  }
	  
	  //adds the legal move options from a given board to the queue
	  public static Queue<Integer> addToQueue(String bd) {
		  int[] legMoves = Hash15Board.getLegalMoves(bd);
		  for(int i = 0; i <= legMoves.length - 1; i++){
				int legalMove = legMoves[i];
				moveOptions.add(legalMove);	
		  }
		  return moveOptions;
	  }
	}

