/**
 * 
 */

/**
 * @author Jacob Wildenhaus
 *
 */
public class Hash15Driver {

	public static final String solvedBd = "123456789ABCDEF0";
	public static void main(String[] args) {
		
		//starts taking longer after a depth of 16
    String newBoard = Hash15Board.scrambleBoard(5);
    System.out.println("The newly scrambled board: ");
	Hash15Board.printBoard(newBoard);
	
	Hash15Board.brutalSolver(newBoard, 2);
	
  }
}