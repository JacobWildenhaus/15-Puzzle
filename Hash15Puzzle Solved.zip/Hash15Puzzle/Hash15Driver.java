/**
 * 
 */
import java.util.*;
/**
 * @author Jacob Wildenhaus
 *
 */
public class Hash15Driver {

	public static final String solvedBd = "123456789ABCDEF0";
	public static void main(String[] args) {
		
    String newBoard = Hash15Board.scrambleBoard(5);
	Hash15Board.printBoard(newBoard);
	
	Hash15Board.brutalSolver(newBoard, 1);
	
  }
}